<?php include 'header.php';?>
      <div id='componentlayout437149' class='bann_container flt ' >
         <p><img src="assets/img/io-gpon-banner.jpg" class="img-responsive" alt="banner" /></p>
      </div>
      <div id='componentlayout438792' class='landing_layout flt ' >
         <div id='componentlayout438793' class='container ' >
            <div id='componentlayout438794' class='landing_wrapper flt ' >
               <div id='componentlayout438796' class='landing_main_head flt ' >
                  <p><span>IOT & GPON</span></p>
               </div>
               <div id='componentlayout438797' class='landing_main_desc flt ' >
                  Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable. If you are going to use a passage of Lorem Ipsum, 
               </div>
               <div id='componentlayout438798' class='row ' >
                  <div id='componentlayout438799' class='col-sm-6 ' >
                     <div id='componentlayout438801' class='landing_div_imgs flt ' >
                        <div class="flt" style="cursor: pointer"><span><img src="assets/img/IOT-Pic.jpg" class="img-responsive" alt="rurutek" /></span></div>
                     </div>
                  </div>
                  <div id='componentlayout438800' class='col-sm-6 ' >
                     <div id='componentlayout438802' class='landing_div_cont flt ' >
                        <div id='componentlayout438803' class='ld_heads flt ' >
                           <p><span>Internet Of things</span></p>
                        </div>
                        <div id='componentlayout438804' class='ld_desc flt about-desc' data-aos="fade-left" data-aos-duration="1200">
                           <p class="inner-paragraph-justify"> The internet of things, or IoT, is a system of interrelated computing devices, mechanical and digital machines, objects, animals or people that are provided with unique identifiers (UIDs) and the ability to transfer data over a network without requiring human-to-human or human-to-computer interaction.
                              A thing in the internet of things can be a person with a heart monitor implant, a farm animal with a biochip transponder, an automobile that has built-in sensors to alert the driver when tire pressure is low or any other natural or man-made object that can be assigned an Internet Protocol (IP) address and is able to transfer data over a network.
                           </p>
                        </div>
                     </div>
                  </div>
                  <div id='componentlayout438806' class='clearfix ' >
                  </div>
                  <div id='componentlayout438807' class='col-sm-6 ' >
                     <div id='componentlayout438810' class='landing_div_cont flt alter_cont_div ' >
                        <div id='componentlayout438811' class='ld_heads flt ' >
                           <p><span>GPON</span></p>
                        </div>
                        <div id='componentlayout438812' class='ld_desc flt about-desc' data-aos="fade-right" data-aos-duration="1200">
                           <p class="inner-paragraph-justify">GPON stands for Gigabit Passive Optical Networks. GPON is a point-to-multi point access mechanism. Its main characteristic is the use of passive splitters in the fibre distribution network, enabling one single feeding fibre from the provider's central office to serve multiple homes and small businesses.</p>
                        </div>
                     </div>
                  </div>
                  <div id='componentlayout438808' class='col-sm-6 ' >
                     <div id='componentlayout438809' class='landing_div_imgs flt alter_img_div ' >
                        <p><span><img src="assets/img/gpon.jpg" class="img-responsive" alt="rurutek" /></span></p>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <?php include 'footer.php';?>