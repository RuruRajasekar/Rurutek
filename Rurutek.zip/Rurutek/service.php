<?php include 'header.php';?>
      <div id='componentlayout437149' class='bann_container flt ' >
         <p><img src="assets/img/service-banner.jpg" class="img-responsive" alt="banner" /></p>
      </div>
      <div id='componentlayout438792' class='landing_layout flt ' >
         <div id='componentlayout438793' class='container ' >
            <div id='componentlayout438794' class='landing_wrapper flt ' >
               <div id='componentlayout438796' class='landing_main_head flt ' >
                  <p><span>Our Services</span></p>
               </div>
               <div id='componentlayout438797' class='landing_main_desc flt ' >
                  Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable. If you are going to use a passage of Lorem Ipsum, 
               </div>
               <div id='componentlayout438798' class='row ' >
                  <div id='componentlayout438799' class='col-sm-6'>
                     <div id='componentlayout438801' class='landing_div_imgs flt '>
                        <div class="flt animate__animated animate__zoomIn" href="#" style="cursor: pointer"><span><img src="assets/img/bulletcam.png" class="img-responsive" alt="rurutek" /></span></div>
                     </div>
                  </div>
                  <div id='componentlayout438800' class='col-sm-6 ' >
                     <div id='componentlayout438802' class='landing_div_cont flt ' >
                        <div id='componentlayout438803' class='ld_heads flt ' >
                           <p><span>Bullet Camera</span></p>
                        </div>
                        <div id='componentlayout438804' class='ld_desc flt ' data-aos="fade-left" data-aos-duration="1200">
                        <p class="inner-paragraph-justify">The main benefits of bullet cameras are their range and installation. Bullet cameras have a longer range which makes them ideal for viewing large areas like backyards and parking lots. Also, bullet cameras are easier to install, and due to the shape of the bullet camera bigger lenses can be fitted to its body. Ideal for outdoor use, the tip of the bullet camera includes a small lip which helps protect against glare and weather.
                        </p>
                        </div>
                     </div>
                  </div>
                  <div id='componentlayout438806' class='clearfix ' >
                  </div>
                  <div id='componentlayout438807' class='col-sm-6 ' >
                     <div id='componentlayout438810' class='landing_div_cont flt alter_cont_div ' >
                        <div id='componentlayout438811' class='ld_heads flt ' >
                           <p><span>Dome Camera</span></p>
                        </div>
                        <div id='componentlayout438812' class='ld_desc flt ' data-aos="fade-right" data-aos-duration="1200">
                           <p class="inner-paragraph-justify">Dome Security Cameras are named for their dome-like shape. Dome cameras are commonly used in surveillance systems inside of homes, casinos, retail stores, and restaurants. This is because dome cameras are more fashionable and blend in very well with their surroundings. Because of their dome shape, it is difficult for someone to tell which direction the lens of a Dome Camera is actually aiming. When shopping for a Dome Camera, you should consider if you need night vision, in which case you should look at an infrared dome camera.</p>
                        </div>
                     </div>
                  </div>
                  <div id='componentlayout438808' class='col-sm-6 ' >
                     <div id='componentlayout438809' class='landing_div_imgs flt alter_img_div ' >
                        <p><span><img src="assets/img/Dome-Camera.png" class="img-responsive" alt="rurutek" /></span></p>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <?php include 'footer.php';?>