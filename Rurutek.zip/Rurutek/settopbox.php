<?php include 'header.php';?>
      <div id='componentlayout437149' class='bann_container flt '>
			<p><img src="assets/img/set_top_bann_new.jpg" class="img-responsive" alt="banner" /></p>
		</div>
<div id='componentlayout438792' class='landing_layout flt'>
    <div id='componentlayout438793' class='container ' >
       <div id='componentlayout438794' class='landing_wrapper flt ' >
          <div id='componentlayout438796' class='landing_main_head flt ' >
             <span>Set top Box</span>
          </div>
          <div id='componentlayout438797' class='landing_main_desc flt about-desc' >
             Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable. If you are going to use a passage of Lorem Ipsum, 
          </div>
          <div id='componentlayout438798' class='row ' >
             <div id='componentlayout438799' class='col-sm-6 ' >
                <div id='componentlayout438801' class='landing_div_imgs flt ' >
                   <div class="flt"><span><img src="assets/img/satellite_inn_img.jpg" class="img-responsive" alt="rurutek" /></span></div>
                </div>
             </div>
             <div id='componentlayout438800' class='col-sm-6 ' >
                <div id='componentlayout438802' class='landing_div_cont flt ' >
                   <div id='componentlayout438803' class='ld_heads flt ' >
                      <span>Satellite </span><br>Set top Box 
                   </div>
                   <div id='componentlayout438804' class='ld_desc flt about-desc' data-aos="fade-left" data-aos-duration="1200">
                      Digital Satellite set top box with fully compliant of DVB-S2 Standards, advanced CAS and Highly
                      enriched User Interface options with an effective user-friendly feature.
                   </div>
                   <div id='componentlayout438805' class='ld_feats flt'>
                      <div class="lay_icons" data-aos="fade-up"><img src="assets/img/hdmi_icon.png" class="img-responsive" alt="" /><br />
                         HDMI
                      </div>
                      <div class="lay_icons" data-aos="fade-up" data-aos-delay="300"><img src="assets/img/usb_icon.png" class="img-responsive" alt="" /><br />
                         USB
                      </div>
                      <div class="lay_icons" data-aos="fade-up" data-aos-delay="600"><img src="assets/img/fullhd_icon.png" class="img-responsive" alt="" /><br />
                         FULL HD
                      </div>
                   </div>
                </div>
             </div>
             <div id='componentlayout438806' class='clearfix ' >
             </div>
             <div id='componentlayout438807' class='col-sm-6 ' >
                <div id='componentlayout438810' class='landing_div_cont flt alter_cont_div ' >
                   <div id='componentlayout438811' class='ld_heads flt ' >
                      <span>Terrestrial</span><br>Set top Box 
                   </div>
                   <div id='componentlayout438812' class='ld_desc flt about-desc' data-aos="fade-right" data-aos-duration="1200">
                      Digital Terrestrial set top box with fully compliant of DVB-T Standards, advanced CAS and Highly
                      enriched User Interface options with an effective user-friendly feature.
                   </div>
                   <div id='componentlayout438813' class='ld_feats flt ' >
                      <div class="lay_icons" data-aos="fade-up"><img src="assets/img/hdmi_icon.png" class="img-responsive" alt="" /><br />
                         HDMI
                      </div>
                      <div class="lay_icons" data-aos="fade-up" data-aos-delay="300"><img src="assets/img/usb_icon.png" class="img-responsive" alt="" /><br />
                         USB
                      </div>
                      <div class="lay_icons" data-aos="fade-up" data-aos-delay="600"><img src="assets/img/fullhd_icon.png" class="img-responsive" alt="" /><br />
                         FULL HD
                      </div>
                   </div>
                </div>
             </div>
             <div id='componentlayout438808' class='col-sm-6 ' >
                <div id='componentlayout438809' class='landing_div_imgs flt alter_img_div ' >
                   <p><span><img src="assets/img/terrestrial_box_img2.png" class="img-responsive" alt="rurutek" /></span></p>
                </div>
             </div>
             <div id='componentlayout438814' class='clearfix ' >
             </div>
             <div id='componentlayout438815' class='col-sm-6 ' >
                <div id='componentlayout438816' class='landing_div_imgs flt ' >
                   <p><span><img src="assets/img/set_top_box_img.jpg" class="img-responsive" alt="rurutek" /></span></p>
                </div>
             </div>
             <div id='componentlayout438817' class='col-sm-6 ' >
                <div id='componentlayout438818' class='landing_div_cont flt ' >
                   <div id='componentlayout438821' class='ld_heads flt ' >
                      <span>Cable</span><br>Set top Box 
                   </div>
                   <div id='componentlayout438820' class='ld_desc flt about-desc' data-aos="fade-left" data-aos-duration="1200">
                      Digital cable set top box with fully compliant of DVB-C Standards and Highly enriched User Interface
                      options with an effective user-friendly feature.
                   </div>
                   <div id='componentlayout438813' class='ld_feats flt ' >
                     <div class="lay_icons" data-aos="fade-up"><img src="assets/img/hdmi_icon.png" class="img-responsive" alt="" /><br />
                        HDMI
                     </div>
                     <div class="lay_icons" data-aos="fade-up" data-aos-delay="300"><img src="assets/img/usb_icon.png" class="img-responsive" alt="" /><br />
                        USB
                     </div>
                     <div class="lay_icons" data-aos="fade-up" data-aos-delay="600"><img src="assets/img/fullhd_icon.png" class="img-responsive" alt="" /><br />
                        FULL HD
                     </div>
                  </div>
                </div>
             </div>
             <div id='componentlayout438822' class='clearfix ' >
             </div>
             <div id='componentlayout438823' class='col-sm-6 ' >
                <div id='componentlayout438826' class='landing_div_cont flt alter_cont_div ' >
                   <div id='componentlayout438827' class='ld_heads flt ' >
                      <span>IPTV</span><br>Set top Box 
                   </div>
                   <div id='componentlayout438820' class='ld_desc flt about-desc' data-aos="fade-left" data-aos-duration="1200">
                      Digital cable set top box with fully compliant of DVB-C Standards and Highly enriched User Interface
                      options with an effective user-friendly feature.
                   </div>
                   <div id='componentlayout438828' class='ld_desc flt ' data-aos="fade-right" data-aos-duration="1200">
                   </div>
                   <div id='componentlayout438813' class='ld_feats flt'>
                     <div class="lay_icons" data-aos="fade-up"><img src="assets/img/hdmi_icon.png" class="img-responsive" alt="" /><br />
                        HDMI
                     </div>
                     <div class="lay_icons" data-aos="fade-up" data-aos-delay="300"><img src="assets/img/usb_icon.png" class="img-responsive" alt="" /><br />
                        USB
                     </div>
                     <div class="lay_icons" data-aos="fade-up" data-aos-delay="600"><img src="assets/img/fullhd_icon.png" class="img-responsive" alt="" /><br />
                        FULL HD
                     </div>
                  </div>
                </div>
             </div>
             <div id='componentlayout438824' class='col-sm-6 ' >
                <div id='componentlayout438825' class='landing_div_imgs flt alter_img_div ' >
                   <p><span><img src="assets/img/iptv_box_img.jpg" class="img-responsive" alt="rurutek" /></span></p>
                </div>
             </div>
          </div>
       </div>
    </div>
 </div>
 <?php include 'footer.php';?>